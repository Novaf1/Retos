function snakeAILoop(game){
    //TODO EL CODIGO DEBE IR DENTRO DE ESTA FUNCION
    //PUEDE USAR {this.memory} PARA PERSISTIR DATOS Y UTILIZARLOS EN LA SIGUIENTE ITERACION
    //REEMPLAZA ESTE CODIGO!
   
    function getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    }

    let Directions = ["N","S","E","W"];//Direcciones Posibles
    let CurrentDireccion = this.direction; //Direccion Actual

    let NewDirection = Directions[getRandomInt(0,3)];
    let isBackwards = true;

    while(isBackwards){
        if(!((CurrentDireccion == "N" && NewDirection == "S") || (CurrentDireccion == "S" && NewDirection == "N") || (CurrentDireccion == "W" && NewDirection == "E") || (CurrentDireccion == "E" && NewDirection == "W")))
        {
            isBackwards = false; 
        } else {
            NewDirection = Directions[getRandomInt(0,3)];          
        }
    }
    return NewDirection;
};